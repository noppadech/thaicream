<?php

		include('da_commentorder.php');

		class Mo_commentorder extends Da_commentorder {

		}
		