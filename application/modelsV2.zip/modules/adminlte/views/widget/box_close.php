	</div>
	<?php if (!empty($footer)): ?>
		<div class='box-footer'><?php echo $footer; ?></div>
	<?php endif; ?>
</div>