<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Work_now extends Admin_Controller {
	public function __construct() {
		parent::__construct();
		$this->load->library('form_builder');
		$this->load->library('form_validation');
		$this->load->model('mo_work_now');
		$this->load->model('mo_commentorder');
		$this->load->helper('url');
		
		if(!empty($this->config->item('ci_bootstrap')['progect_id'])){
			$key = array_search($this->config->item('ci_bootstrap')['progect_id'],$this->session->userdata('cotton_us'));
		}
		
		//echo $this->config->item('ci_bootstrap')['progect_id'];
	}
	
	public function index($id=null) {
		
		$this->load->library('form_validation');
		$this->mPageTitle = 'งานปัจจุบัน';
		
		$this->mViewData['data_cat'] = $this->mo_work_now->get_by_key_groupby($this->config->item('ci_bootstrap')['progect_id'],$id);
		
		//dd($this->mViewData['data_cat']);
		
		$form = $this->form_builder->create_form();
		$this->mViewData['form'] = $form;
		$this->render('work_now/v_work_now');
	}
	
	public function persen_all_group($order_id=NULL,$group_id=NULL,$link=NULL) {
		
		return $this->mo_work_now->get_by_persec_all_group($order_id,$link);
		
	}
	
	public function showall($id=null) {
		
		$this->load->library('form_validation');
		$this->mPageTitle = 'งานปัจจุบัน';
		
		$this->mViewData['data_cat'] = $this->mo_work_now->get_by_key_group($this->config->item('ci_bootstrap')['progect_id'],$id);
		
		//dd($this->mViewData['data_cat']);
		
		$form = $this->form_builder->create_form();
		$this->mViewData['form'] = $form;
		$this->render('work_now/v_work_now_in');
	}

	public function create($id=NULL,$order_id=NULL) {

		$this->load->library('form_validation');
		$this->form_validation->set_rules('order_id','เลขที่เอกสาร', 'required');
		$this->form_validation->set_rules('work_now_detail','รายการ', 'required');
				
		$this->mViewData['work_now'] = '';
		$this->mViewData['order_id'] = $order_id;

		if(($id!=NULL && $id!=0) || !empty($this->input->post('work_now_id',true))){
			if($this->form_validation->run() == FALSE ){
				//if($order_id==NULL){
					$this->mViewData['work_now'] = $this->mo_work_now->get_by_key($id);
				//}else{
					
				//}
			}
			else{
				$this->mo_work_now->work_now_id = $this->input->post('work_now_id',true);
				$this->mo_work_now->order_id = $this->input->post('order_id',true);
				$this->mo_work_now->group_module_id = $this->config->item('ci_bootstrap')['progect_id'];
				$this->mo_work_now->work_now_detail = $this->input->post('work_now_detail',true);
				$this->mo_work_now->work_now_status = $this->input->post('work_now_status',true);
			//	$this->mo_work_now->admin_id = $this->input->post('admin_id',true);
				$this->mo_work_now->manager_id = $this->session->userdata('user_id');
				
				if ($this->keymanager !== false || $this->keyadmin !== false || $this->keywebmaster !== false){
					$this->mo_work_now->updates();
				}

				redirect($this->config->item('ci_bootstrap')['link_module'].'/work_now/showall/'.$order_id, 'refresh');
			}
		}
		else{
			if($this->form_validation->run() == FALSE){
				
			}
			else{
			$this->mo_work_now->work_now_id = $this->input->post('work_now_id',true);
				$this->mo_work_now->order_id = $this->input->post('order_id',true);
				$this->mo_work_now->group_module_id = $this->config->item('ci_bootstrap')['progect_id'];
				$this->mo_work_now->work_now_detail = $this->input->post('work_now_detail',true);
				$this->mo_work_now->work_now_status = $this->input->post('work_now_status',true);
				$this->mo_work_now->admin_id = 0;
				$this->mo_work_now->manager_id = $this->session->userdata('user_id');
				
				if ($this->keymanager !== false || $this->keyadmin !== false || $this->keywebmaster !== false){
					$this->mo_work_now->inserts();
				}
				redirect($this->config->item('ci_bootstrap')['link_module'].'/work_now/showall/'.$order_id, 'refresh');
			}
		}

		$this->mPageTitle = 'เพิ่มงาน';
		
		$form = $this->form_builder->create_form();
		$this->mViewData['form'] = $form;
		$this->render('work_now/v_work_now_create');
	}
	
	public function get_comment($key=null){
		return $this->mo_work_now->get_by_key_order($key);
	}
	
	public function get_comment_com($key=null){
		return $this->mo_commentorder->get_by_key_order($key);
	}
	
	public function comment() {

		$this->form_validation->set_rules('order_id','Order', 'required');
		$this->form_validation->set_rules('detail','Detail', 'required');
		$ins_com_id = null;
		if($this->form_validation->run() == FALSE){
				
		}else{
			$date = new DateTime("now", new DateTimeZone('Asia/Bangkok') );
			$data_ = array(
						"work_now_id" => $this->input->post('order_id',true),
						"admin_id" => $this->session->userdata('user_id'),
						"work_comment_detail" => $this->input->post('detail',true),
						"comment_date" => $date->format('Y-m-d H:i:s'),
					);
			
			
			$ins_com_id = $this->mo_work_now->inserts_array_comment($data_);
		}
		
		$data_to = array(
			'token' => $this->security->get_csrf_hash(),
			'cks'	=> $ins_com_id
			);

		echo json_encode($data_to);
		
	//	redirect('supportsales/work_now/', 'refresh');
	}
	
	public function comment_com() {

		$this->form_validation->set_rules('order_id','Order', 'required');
		$this->form_validation->set_rules('detail','Detail', 'required');
		$ins_com_id = null;
		if($this->form_validation->run() == FALSE){
				
		}else{
			$date = new DateTime("now", new DateTimeZone('Asia/Bangkok') );
			$data_ = array(
						"work_now_id" => $this->input->post('order_id',true),
						"admin_id" => $this->session->userdata('user_id'),
						"work_comment_detail" => $this->input->post('detail',true),
						"comment_date" => $date->format('Y-m-d H:i:s'),
					);
			
			
			$ins_com_id = $this->mo_work_now->inserts_array_comment($data_);
		}
		
		$data_to = array(
			'token' => $this->security->get_csrf_hash(),
			'cks'	=> $ins_com_id
			);

		echo json_encode($data_to);
		
	//	redirect('supportsales/work_now/', 'refresh');
	}
	
	public function change_status() {

		$this->form_validation->set_rules('order_id','ID No.', 'required');
		$this->form_validation->set_rules('value','Value', 'required');
		
		if($this->form_validation->run() == FALSE){
				
		}else{
			
			$check_st = $this->mo_work_now->get_by_key($this->input->post('order_id',true));
			if(!empty($check_st)){
				if($check_st[0]->work_now_status == 3){
					if($this->keymanager !== false || $this->keyadmin !== false || $this->keywebmaster !== false){
						$data_ = array(
							"work_now_status" => $this->input->post('value',true),
							"work_now_dateend" => date('Y-m-d'),
						);
						
						$data_key = array("work_now_id" => $this->input->post('order_id',true));
						
						
						$this->mo_work_now->updates_array($data_,$data_key);
					}
				}else{
					$data_ = array(
							"work_now_status" => $this->input->post('value',true),
							"work_now_dateend" => date('Y-m-d'),
					);
					
					$data_key = array("work_now_id" => $this->input->post('order_id',true));
					
					
					$this->mo_work_now->updates_array($data_,$data_key);
				}
			}
			
			
		}
		
		$data_to = array(
			'token' => $this->security->get_csrf_hash(),
			);

		echo json_encode($data_to);
		
	//	redirect('supportsales/work_now/', 'refresh');
	}
	
	public function persen($order_id=NULL) {
		
		return $this->mo_work_now->get_by_persec($this->config->item('ci_bootstrap')['progect_id'],$order_id);
		
	}
	
	public function deletes($id=NULL,$order_id=NULL) {
		if($id!=NULL && ($this->keymanager !== false || $this->keyadmin !== false || $this->keywebmaster !== false)){
			$this->mo_work_now->work_now_id = $id;
			$this->mo_work_now->deletes();
		}
		redirect($this->config->item('ci_bootstrap')['link_module'].'/work_now/showall/'.$order_id, 'refresh');
	}
	
	public function delete_comment() {
		$work_comment_id = $this->input->post('order_id',true);
		$cks = false;
		if($work_comment_id!=NULL && ($this->keymanager !== false || $this->keyadmin !== false || $this->keywebmaster !== false)){
			$this->mo_work_now->deletes_comment($work_comment_id);
			$cks = true;
		}
		
		$data_to = array(
			'token' => $this->security->get_csrf_hash(),
			'cks'	=> $cks
			);

		echo json_encode($data_to);
		
		//redirect('supportsales/work_now/', 'refresh');
	}
	
	public function delete_comment_com() {
		$work_comment_id = $this->input->post('order_id',true);
		$cks = false;
		if($work_comment_id!=NULL && ($this->keymanager !== false || $this->keyadmin !== false || $this->keywebmaster !== false)){
			$this->mo_work_now->deletes_comment($work_comment_id);
			$cks = true;
		}
		
		$data_to = array(
			'token' => $this->security->get_csrf_hash(),
			'cks'	=> $cks
			);

		echo json_encode($data_to);
		
		//redirect('supportsales/work_now/', 'refresh');
	}

}
						