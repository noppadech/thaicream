<header>
	<div class="icons"><i class="icon-edit"></i></div>
	<h5>File Manager</h5>
</header>
<div class="accordion-body collapse in body" style="padding-bottom: 0;">
	<div class="elfinder" data-connector="<?php echo $connector; ?>"></div>
</div>