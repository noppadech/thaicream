<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*
  | -------------------------------------------------------------------------
  | CI Bootstrap 3 Configuration
  | -------------------------------------------------------------------------
  | This file lets you define default values to be passed into views
  | when calling MY_Controller's render() function.
  |
  | See example and detailed explanation from:
  | 	/application/config/ci_bootstrap_example.php
 */

$config['ci_bootstrap_menu'] = array(
 'menu' => array(
        'home' => array(
            'name' => 'Home',
            'url' => '../admin/home',
            'icon' => 'fa fa-home',
        ),
		'report' => array(
            'name' => 'Report',
			'url' => 'report',
			'icon' => 'fa fa-users',
			'children' => array(
				'กำลังดำเนินการ' => 'report/now',
				'งานล่าช้า' => 'report/late',
				'งานมีปัญหา' => 'report/problem',
				'เสร็จสิ้น' => 'report/success',
			)
        ),
		'work_list' => array(
            'name' => 'รายละเอียดงาน',
			'url' => 'work_list',
			'icon' => 'fa fa-users',
        ),
		'panel' => array(
            'name' => 'Admin Panel',
            'url' => 'panel',
            'icon' => 'fa fa-cog',
            'children' => array(
                'Admin Users' => 'panel/admin_user',
                'Create Admin User' => 'panel/admin_user_create',
             //   'Admin User Groups' => 'panel/admin_user_group',
            )
        ),
        'util' => array(
            'name' => 'สำองฐานข้อมูล',
            'url' => 'util',
            'icon' => 'fa fa-cogs',
            'children' => array(
                'Database Versions' => 'util/list_db',
            )
        ),
        'logout' => array(
            'name' => 'Sign Out',
            'url' => 'panel/logout',
            'icon' => 'fa fa-sign-out',
        )
    )
	);
				$config['ci_bootstrap_menu']['menu']['report'] = array(
					'name' => 'Report',
					'url' => 'report',
					'icon' => 'fa fa-users',
					'children' => array(
						'กำลังดำเนินการ' => 'report/now',
						'งานล่าช้า' => 'report/late',
						'งานมีปัญหา' => 'report/problem',
						'เสร็จสิ้น' => 'report/success',
					)
				);
