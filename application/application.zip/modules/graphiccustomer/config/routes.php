<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// default controller for this module
$route['graphiccustomer'] = 'home';
$route['filemanager/(:any)'] = 'filemanager/$1';
