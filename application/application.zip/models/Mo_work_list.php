<?php

include('da_work_list.php');

class Mo_work_list extends Da_work_list {
	
	public function get_all_full($key=null) {
		$this->db->from('tc_work_list');
		$this->db->join('admin_users', 'admin_users.id = tc_work_list.admin_id', 'left');
		$this->db->join('admin_group_module', 'admin_group_module.id = tc_work_list.group_module_id', 'left');
		if(!empty($key)){
			$this->db->where('tc_work_list.group_module_id', $key);
		}
		$this->db->order_by('work_id', 'ASC');
		return $this->db->get()->result();
	}
	
	public function get_all_use_array() {
		$this->db->from('tc_work_list');
		$this->db->where('work_status', 1);
		$this->db->order_by('work_id', 'ASC');
		return $this->db->get()->result_array();
	}

}
		