<?php
class Da_order extends MY_Model { 
	public $order_id;
	public $code_id;
	public $name_order;
	public $name_customer;
	public $status;
	public $type_order;
	public $admin_id;
	public $order_date;
	public $order_datelate;
	public $order_date_end;
	public $order_workcount;

	public function inserts() {
		$this->db->set('order_id', $this->order_id);
		$this->db->set('code_id', $this->code_id);
		$this->db->set('name_order', $this->name_order);
		$this->db->set('name_customer', $this->name_customer);
		$this->db->set('status', $this->status);
		$this->db->set('type_order', $this->type_order);
		$this->db->set('order_date', $this->order_date);
		$this->db->set('admin_id', $this->admin_id);
		$this->db->set('order_datelate', $this->order_datelate);
		$this->db->set('order_workcount', $this->order_workcount);
		
		$this->db->from('tc_order');
		$this->db->insert();
		return $this->db->insert_id();
	}

	public function inserts_array($data=null) {
		$this->db->set($data);
		$this->db->from('tc_order');
		$this->db->insert();
		return $this->db->insert_id();
	}
	public function updates_array($data=null,$key=null) {
		return $this->db->update('tc_order', $data, $key);
	}
	public function updates() {
		
		$this->db->set('order_id', $this->order_id);
		$this->db->set('code_id', $this->code_id);
		$this->db->set('name_order', $this->name_order);
		$this->db->set('name_customer', $this->name_customer);
		$this->db->set('status', $this->status);
		$this->db->set('type_order', $this->type_order);
		$this->db->set('order_date', $this->order_date);
		$this->db->set('admin_id', $this->admin_id);
		$this->db->set('order_datelate', $this->order_datelate);
		$this->db->set('order_workcount', $this->order_workcount);
		
		$this->db->from('tc_order');
		$this->db->where('order_id', $this->order_id);
		return $this->db->update();
	}

	public function deletes() {
		$this->db->from('tc_order');
		$this->db->where('order_id', $this->order_id);
		$this->db->delete();
	}

	public function get_all() {
		$this->db->from('tc_order');
		$this->db->order_by('order_id', 'ASC');
		return $this->db->get()->result();
	}

	public function get_by_key($key) {
		$this->db->select('*');
		$this->db->from('tc_order');
		$this->db->where('order_id', $key);
		$query = $this->db->get()->result();
		return $query;
	}

}